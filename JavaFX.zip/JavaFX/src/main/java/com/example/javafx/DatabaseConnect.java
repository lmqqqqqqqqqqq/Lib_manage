package com.example.javafx;

//database connection's information.
import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnect{
    String url = "jdbc:mysql://127.0.0.1:3306/login_schema";
    String Dtusername = "root";
    String Dtpassword = "12345678";

    public Connection connect() throws Exception {
        return DriverManager.getConnection(url, Dtusername, Dtpassword);
    }
}
